from django.contrib import admin
from .models.maquina import Maquina 

admin.site.register(Maquina)